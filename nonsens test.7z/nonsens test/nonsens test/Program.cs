﻿using System;

namespace nonsens_test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("gutten tag ich bin ein baliner Jax");
            Console.Write("Saisho no intUWU o nyūryoku shite kudasai");
            Console.ReadLine();
            int afab = new int();
            afab = int.Parse(Console.ReadLine());

            Console.Write("2-Banme no intuwu o nyūryoku shimasu");
            Console.ReadLine();
            int amab = new int();
            amab = int.Parse(Console.ReadLine());

            /* int uwucat = new int();
             uwucat = amab + afab;
            Console.WriteLine("Your total cubic feet is " + uwucat);
            Console.ReadLine(); */

            /*int UWUGIRL = new int();
            UWUGIRL = amab * afab;
            Console.WriteLine("Your total cubic feet is " + UWUGIRL);
            Console.ReadLine();*/

            if(afab != amab)
            {
                Console.WriteLine("never gonna give you up");
                int uwucat = new int();
                uwucat = amab + afab;
                Console.WriteLine("Your total cubic feet is " + uwucat);
                Console.ReadLine(); 
               
            }
            else
            {
                Console.WriteLine("vivala la C Sharp");
                int UWUGIRL = new int();
                UWUGIRL = amab + afab;
                int MUMGIRL = new int();
                MUMGIRL = UWUGIRL * 3;
                Console.WriteLine("Your total cubic feet is " + MUMGIRL);
                Console.ReadLine();
            }


            Console.WriteLine("wafflejern");
        }
    }
}
